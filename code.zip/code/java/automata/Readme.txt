Pour compiler en ligne de commande :
javac -d bin -cp bin -sourcepath src src/*.java

Pour executer :
java -cp bin Test 
